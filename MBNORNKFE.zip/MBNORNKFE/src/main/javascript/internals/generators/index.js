module.exports = require('yeni-proje-bilesenler');
