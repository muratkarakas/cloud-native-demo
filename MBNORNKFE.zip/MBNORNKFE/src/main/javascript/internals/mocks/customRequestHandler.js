module.exports = (req, res) => {
  res.json(req.query);
};
