const Navigation = require('./Navigation.json');

module.exports = () => ({
  navigation: Navigation,
});
