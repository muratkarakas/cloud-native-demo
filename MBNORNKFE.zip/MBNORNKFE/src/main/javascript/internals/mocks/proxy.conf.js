const protocol = 'http';
const domain = 'localhost';
const port = 6767;
const targetUrl = `${protocol}://${domain}:${port}`;

const backendProxy = {
  '/custompath': {
    target: targetUrl,
    pathRewrite: {
      '^/custompath': '/custompath',
    },
  },
  '/navigation/v1': {
    target: targetUrl,
    pathRewrite: {
      '^/navigation': '/navigation',
    },
  },
};

module.exports = backendProxy;
