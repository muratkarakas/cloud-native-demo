/* eslint-disable no-console */

const jsonServer = require('json-server');
const allDefaultRoutes = require('./json/index');
const defaultWritePaths = require('./routes.json');
const postModifierMiddleware = require('./postModifierMiddleware');
const customRequestHandler = require('./customRequestHandler');
const mockPort = require('./mockport');

const allDefaultRouteValues = allDefaultRoutes();

const server = jsonServer.create();

const router = jsonServer.router(allDefaultRouteValues);

const middlewares = jsonServer.defaults();

// coompletely custom request handler
server.get('/custompath', customRequestHandler);

server.use(jsonServer.bodyParser);

// this middleware sample for response customization based on request.
server.use(postModifierMiddleware);

server.use(middlewares);
server.use(jsonServer.rewriter(defaultWritePaths));
server.use(router);

server.listen(mockPort, () => {
  logStartup();
});

function logStartup() {
  const keys = [];
  // eslint-disable-next-line no-restricted-syntax
  for (const k in allDefaultRouteValues) {
    if (k) {
      keys.push(`/${k}`);
    }
  }

  console.log('JSON Mock Server is running');
  console.log('allDefaultRoutes \n', keys);
  console.log('defaultWritePaths: \n', defaultWritePaths);
  console.log('JSON Mock Server is Ready\n\n');
}
