const argv = require('../../server/argv');
require('dotenv').config();
module.exports = parseInt(argv.mockport || process.env.MOCKPORT || '5000', 10);
