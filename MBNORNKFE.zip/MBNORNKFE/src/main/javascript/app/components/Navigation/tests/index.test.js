import React from 'react';
import Adapter from 'enzyme-adapter-react-16';
import { shallow, configure } from 'enzyme';

import Navigation from '../index';

configure({ adapter: new Adapter() });

const navData = {
  data: [
    {
      id: 1,
      name: 'Test1',
      icon: 'sitemap',
      key: 'test1',
      url: '/',
    },
    {
      id: 2,
      name: 'Test2',
      icon: 'sitemap',
      key: 'test2',
      child: [
        {
          id: 3,
          name: 'Test2-1',
          icon: 'sitemap',
          key: 'test2-1',
          url: '/',
        },
      ],
    },
  ],
};

describe('Navigation render', () => {
  test('renders', () => {
    const wrapper = shallow(<Navigation data={navData} />);

    expect(wrapper.exists()).toBe(true);
  });

  test('Navigation render if data is null', () => {
    const wrapper = shallow(<Navigation data={{ data: null }} />);

    expect(wrapper.html()).toBeNull();
  });

  it('Navigation active item state check', () => {
    const wrapper = shallow(<Navigation data={navData} />);
    wrapper.setState({ activeItem: 'test1' });
    wrapper.instance().handleItemClick('test2');
    expect(wrapper.instance().state.activeItem).toEqual('test2');
  });

  it('Navigation item click check', () => {
    const wrapper = shallow(<Navigation data={navData} />);
    wrapper.setState({ activeItem: 'test2-1' });
    const link = wrapper.find('#navItem1').at(0);
    link.simulate('click');
    expect(wrapper.instance().state.activeItem).toEqual('test1');
  });

  it('Navigation subitem click check', () => {
    const wrapper = shallow(<Navigation data={navData} />);
    wrapper.setState({ activeItem: 'test1' });
    const link = wrapper.find('#navItem3').at(0);
    link.simulate('click');
    expect(wrapper.instance().state.activeItem).toEqual('test2-1');
  });
});
