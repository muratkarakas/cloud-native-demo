/**
 *
 * Navigation
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import { Menu, Icon, Dropdown } from 'tcmb-ui-components';

/* eslint-disable react/prefer-stateless-function */
class Navigation extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      activeItem: 'home',
    };
  }

  handleItemClick = value => {
    this.setState({ activeItem: value });
  };

  CreateSubMenuItems = data => {
    const subMenuItems = data.map(item => (
      <Dropdown.Item
        key={item.key}
        id={`navItem${item.id}`}
        as={Link}
        to={item.url}
        icon={item.icon}
        active={this.state.activeItem === item.key}
        onClick={() => this.handleItemClick(item.key)}
        text={item.name}
      />
    ));

    return subMenuItems;
  };

  CreateMenuItems = data => {
    const menuItems = data.map(item => {
      if (item.child) {
        return (
          <Dropdown item text={item.name} key={item.key} id={`navItem${item.id}`}>
            <Dropdown.Menu>{this.CreateSubMenuItems(item.child)}</Dropdown.Menu>
          </Dropdown>
        );
      }

      return (
        <Menu.Item
          id={`navItem${item.id}`}
          key={item.key}
          as={Link}
          to={item.url}
          name={item.key}
          active={this.state.activeItem === item.key}
          onClick={() => this.handleItemClick(item.key)}>
          {item.icon && <Icon name={item.icon} />}
          {item.name}
        </Menu.Item>
      );
    });

    return menuItems;
  };

  render() {
    const { data } = this.props.data;
    if (!data) {
      return null;
    }

    return (
      <Menu pointing fluid secondary vertical>
        {this.CreateMenuItems(data)}
      </Menu>
    );
  }
}

Navigation.propTypes = {
  data: PropTypes.object,
};

export default Navigation;
