/**
 *
 * Footer
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { Segment, Container, Grid, List, Image } from 'tcmb-ui-components';
import LocaleToggle from '../../containers/LanguageProvider/LocaleToggle';

/* eslint-disable react/prefer-stateless-function */
class Footer extends React.Component {
  constructor(props) {
    super(props);

    this.state = {};
  }

  CreateFooterNav = data => {
    const items = data.map(item => <List.Item key={item.key}>{item.name}</List.Item>);

    return items;
  };

  render() {
    const { data } = this.props.data;
    if (!data) {
      return null;
    }

    return (
      <Segment inverted vertical textAlign="center" className="footer">
        <Container fluid>
          <Grid divided inverted stackable columns={5}>
            <Grid.Column>
              <List link inverted>
                {this.CreateFooterNav(data)}
              </List>
            </Grid.Column>

            <Grid.Column>
              <List link inverted>
                {this.CreateFooterNav(data)}
              </List>
            </Grid.Column>

            <Grid.Column>
              <List link inverted>
                {this.CreateFooterNav(data)}
              </List>
            </Grid.Column>

            <Grid.Column verticalAlign="bottom">
              <Image centered size="mini" src={this.props.siteLogo} />
              {this.props.copyright}
            </Grid.Column>
            <Grid.Column verticalAlign="bottom">
              <LocaleToggle />
            </Grid.Column>
          </Grid>
        </Container>
      </Segment>
    );
  }
}

Footer.propTypes = {
  siteLogo: PropTypes.string,
  data: PropTypes.object,
  copyright: PropTypes.string,
};

export default Footer;
