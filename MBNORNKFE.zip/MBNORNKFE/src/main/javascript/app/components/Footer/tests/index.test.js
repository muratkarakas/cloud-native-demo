import React from 'react';
import Adapter from 'enzyme-adapter-react-16';
import { shallow, configure } from 'enzyme';

import Footer from '../index';

configure({ adapter: new Adapter() });

const navData = {
  data: [
    {
      id: 1,
      name: 'Test1',
      icon: 'sitemap',
      key: 'test1',
      url: '/',
    },
    {
      id: 2,
      name: 'Test2',
      icon: 'sitemap',
      key: 'test2',
      url: '/',
    },
  ],
};

describe('Footer render', () => {
  test('renders', () => {
    const wrapper = shallow(<Footer data={navData} />);

    expect(wrapper.exists()).toBe(true);
  });

  test('Footer render if data is null', () => {
    const wrapper = shallow(<Footer data={{ data: null }} />);

    expect(wrapper.html()).toBeNull();
  });
});
