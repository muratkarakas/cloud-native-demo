/**
 *
 * Header
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { Container, Image, Menu } from 'tcmb-ui-components';

/* eslint-disable react/prefer-stateless-function */
class Header extends React.Component {
  constructor(props) {
    super(props);

    this.state = {};
  }

  render() {
    const { siteLogo, siteName } = this.props;
    if (!siteLogo) {
      return null;
    }

    return (
      <Menu id="header" className="header-fixed" fixed="top" inverted>
        <Container fluid>
          <Menu.Item header>
            <Image size="mini" src={siteLogo} />
            {siteName}
          </Menu.Item>
        </Container>
      </Menu>
    );
  }
}

Header.propTypes = {
  siteLogo: PropTypes.string,
  siteName: PropTypes.string,
};

export default Header;
