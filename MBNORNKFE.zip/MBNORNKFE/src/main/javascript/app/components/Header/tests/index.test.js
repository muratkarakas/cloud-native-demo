import React from 'react';
import Adapter from 'enzyme-adapter-react-16';
import { shallow, configure } from 'enzyme';

import Header from '../index';

configure({ adapter: new Adapter() });

describe('Header', () => {
  test('renders', () => {
    const wrapper = shallow(<Header siteLogo="" />);

    expect(wrapper.exists()).toBe(true);
  });
});
