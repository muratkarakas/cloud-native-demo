const logo = require('./logo.png');

export default {
  logo,
};
