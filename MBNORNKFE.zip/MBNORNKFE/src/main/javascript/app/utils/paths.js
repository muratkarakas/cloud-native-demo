export const APIBASE = window.location.origin;
export const API_NAVIGATION_URL = `${APIBASE}/navigation/v1/`;
