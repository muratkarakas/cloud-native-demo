/*
 * HelloWorld2 Messages
 *
 * This contains all the text for the HelloWorld2 container.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.containers.HelloWorld';

export default defineMessages({
  hello: {
    id: `${scope}.hello`,
    defaultMessage: 'Örnek sayfa. Beni silmeyi unutmayınız!',
  },
});
