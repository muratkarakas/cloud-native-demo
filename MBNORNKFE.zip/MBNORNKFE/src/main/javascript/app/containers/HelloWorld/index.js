/**
 *
 * HelloWorld2
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { injectIntl, intlShape, FormattedMessage } from 'react-intl';
import { compose } from 'redux';

import messages from './messages';

/* eslint-disable react/prefer-stateless-function */
class HelloWorld extends React.Component {
  render() {
    return (
      <div>
        <p>{this.props.intl.formatMessage(messages.hello)}</p>
        <FormattedMessage {...messages.hello} />
      </div>
    );
  }
}

HelloWorld.propTypes = {
  dispatch: PropTypes.func.isRequired,
  intl: intlShape.isRequired,
};

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  null,
  mapDispatchToProps,
);

export default compose(withConnect)(injectIntl(HelloWorld));
