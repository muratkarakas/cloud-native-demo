import React from 'react';
import { browserHistory } from 'react-router-dom';
import { shallowWithIntl } from 'utils/intl-enzyme-test-helper';
import { Provider } from 'react-redux';
import configureStore from '../../../configureStore';

import HelloWorld from '../index';

describe('HelloWorld', () => {
  let store;
  beforeAll(() => {
    store = configureStore({}, browserHistory);
  });

  test('renders', () => {
    const dispatch = jest.fn();
    const wrapper = shallowWithIntl(
      <Provider store={store}>
        <HelloWorld dispatch={dispatch} />
      </Provider>,
    );

    expect(wrapper.exists()).toBe(true);
  });
});
