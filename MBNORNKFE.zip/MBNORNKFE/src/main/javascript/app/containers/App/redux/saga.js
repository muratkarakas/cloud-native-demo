/*
 *
 * Navigation saga
 *
 */

import request from 'utils/request';
import { takeLatest, call, put } from 'redux-saga/effects';
import { API_NAVIGATION_URL } from '../../../utils/paths';
import { getNavigationSuccess } from './actions';
import { GET_NAVIGATION } from './constants';

export function* getNavigationSaga() {
  const requestURL = API_NAVIGATION_URL;
  const options = {
    method: 'GET',
  };

  try {
    const result = yield call(request, requestURL, options);
    yield put(getNavigationSuccess(result.data.data));
  } catch (err) {
    // yield put(getNavigationFailure(err));
  }
}

// Individual exports for testing
export default function* navigationSaga() {
  yield takeLatest(GET_NAVIGATION, getNavigationSaga);
}
