/*
 * AppConstants
 * Each action has a corresponding type, which the reducer knows and picks up on.
 * To avoid weird typos between the reducer and the actions, we save them as
 * constants here. We prefix them with 'yourproject/YourComponent' so we avoid
 * reducers accidentally picking up actions they shouldn't.
 */

export const DEFAULT_ACTION = 'app/containers/App/DEFAULT_ACTION';
export const GET_NAVIGATION = 'app/containers/App/GET_NAVIGATION';
export const GET_NAVIGATION_SUCCESS = 'app/containers/App/GET_NAVIGATION_SUCCESS';
