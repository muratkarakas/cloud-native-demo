/*
 *
 * Questions reducer
 *
 */

import { fromJS } from 'immutable';
import { DEFAULT_ACTION, GET_NAVIGATION_SUCCESS } from './constants';
import menu from './menu';

export const initialState = fromJS({
  data: menu.data,
});

function navigationReducer(state = initialState, action) {
  switch (action.type) {
    case DEFAULT_ACTION:
      return state;
    case GET_NAVIGATION_SUCCESS:
      return state.merge({ data: action.data });
    default:
      return state;
  }
}

export default navigationReducer;
