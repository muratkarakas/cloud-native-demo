import { fromJS } from 'immutable';
import navigationReducer from '../redux/reducer';
import { getNavigationSuccess } from '../redux/actions';
import { DEFAULT_ACTION } from '../redux/constants';
import menu from '../redux/menu';

describe('navigationReducer', () => {
  let state;
  beforeEach(() => {
    state = fromJS({
      data: menu.data,
    });
  });
  it('returns the initial state', () => {
    const expectedResult = state;
    expect(navigationReducer(undefined, {})).toEqual(expectedResult);
  });
  it('returns the default state', () => {
    const expectedResult = state;
    expect(navigationReducer(undefined, { type: DEFAULT_ACTION })).toEqual(expectedResult);
  });
  it('should handle the getNavigationSuccess action correctly', () => {
    const navigation = [];
    const expectedResult = state.merge({ data: navigation });
    expect(navigationReducer(state, getNavigationSuccess(navigation))).toEqual(expectedResult);
  });
});
