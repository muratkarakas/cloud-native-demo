const menu = {
  data: [
    {
      id: 1,
      name: 'Anasayfa',
      icon: 'home',
      key: 'home',
      url: '/',
    },
    {
      id: 2,
      name: 'Item 1',
      icon: 'file code outline',
      key: 'item1',
      url: '/item1',
    },
    {
      id: 3,
      name: 'Item 2',
      icon: 'file code outline',
      key: 'item2',
      url: '/item2',
    },
    {
      id: 4,
      name: 'Item 3',
      icon: 'file code outline',
      key: 'item3',
      child: [
        {
          id: 5,
          name: 'Item 3-1',
          icon: 'file code outline',
          key: 'item31',
          url: '/item31',
        },
        {
          id: 6,
          name: 'Item 3-2',
          icon: 'file code outline',
          key: 'item32',
          url: '/item32',
        },
      ],
    },
  ],
};

export default menu;
