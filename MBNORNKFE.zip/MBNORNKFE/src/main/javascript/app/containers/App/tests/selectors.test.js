import { fromJS } from 'immutable';

import { makeSelectLocation, makeSelectNavigation } from 'containers/App/redux/selectors';

describe('makeSelectLocation', () => {
  const locationStateSelector = makeSelectLocation();
  it('should select the location', () => {
    const mockedState = fromJS({
      router: { location: { pathname: '/foo' } },
    });
    expect(locationStateSelector(mockedState)).toEqual(mockedState.getIn(['router', 'location']).toJS());
  });
});

describe('makeSelectNavigation', () => {
  const navSelector = makeSelectNavigation();
  it('should select the nav', () => {
    const data = {
      data: [
        {
          id: 1,
          name: 'Anasayfa',
          icon: 'home',
          key: 'home',
          url: '/',
        },
      ],
    };
    const mockedState = fromJS({
      navigation: data,
    });
    expect(navSelector(mockedState)).toEqual(data);
  });
});
