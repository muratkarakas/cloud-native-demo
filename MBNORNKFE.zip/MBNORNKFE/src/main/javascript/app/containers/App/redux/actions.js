/*
 *
 * Questions actions
 *
 */

import { DEFAULT_ACTION, GET_NAVIGATION, GET_NAVIGATION_SUCCESS } from './constants';

export function defaultAction() {
  return {
    type: DEFAULT_ACTION,
  };
}

export function getNavigation() {
  return {
    type: GET_NAVIGATION,
  };
}

export function getNavigationSuccess(data) {
  return {
    type: GET_NAVIGATION_SUCCESS,
    data,
  };
}
