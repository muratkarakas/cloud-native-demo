import { defaultAction, getNavigation, getNavigationSuccess } from '../redux/actions';
import { DEFAULT_ACTION, GET_NAVIGATION, GET_NAVIGATION_SUCCESS } from '../redux/constants';

describe('Navigation actions', () => {
  describe('Default Action', () => {
    it('has a type of DEFAULT_ACTION', () => {
      const expected = {
        type: DEFAULT_ACTION,
      };
      expect(defaultAction()).toEqual(expected);
    });
  });

  describe('getNavigation', () => {
    it('should return the correct getNavigation type', () => {
      const expectedResult = {
        type: GET_NAVIGATION,
      };

      expect(getNavigation()).toEqual(expectedResult);
    });
  });
  describe('getNavigationSuccess', () => {
    it('should return the correct getNavigationSuccess type and the passed navigation', () => {
      const expectedResult = {
        type: GET_NAVIGATION_SUCCESS,
        data: [],
      };

      expect(getNavigationSuccess([])).toEqual(expectedResult);
    });
  });
});
