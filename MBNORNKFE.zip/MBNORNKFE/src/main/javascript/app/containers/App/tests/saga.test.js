import { put, takeLatest } from 'redux-saga/effects';

import { getNavigationSuccess } from '../redux/actions';

import navigationSaga, { getNavigationSaga } from '../redux/saga';

import { GET_NAVIGATION } from '../redux/constants';

/* eslint-disable redux-saga/yield-effects */
describe('getNavigationSaga', () => {
  let getNavigationGenerator;

  beforeEach(() => {
    getNavigationGenerator = getNavigationSaga();

    const callDescriptor = getNavigationGenerator.next().value;
    expect(callDescriptor).toMatchSnapshot();
  });

  it('should dispatch the getNavigationSuccess action if it requests the data successfully', () => {
    const response = {
      data: {
        data: [
          {
            id: 1,
            name: 'Anasayfa',
            icon: 'home',
            key: 'home',
            url: '/',
          },
        ],
      },
    };
    const putDescriptor = getNavigationGenerator.next(response).value;
    expect(putDescriptor).toEqual(put(getNavigationSuccess(response.data.data)));
  });
});

describe('navigationSaga nav data', () => {
  const navigationDataSaga = navigationSaga();

  it('should load data and watch for GET_NAVIGATION action', () => {
    const takeLatestDescriptor = navigationDataSaga.next().value;
    expect(takeLatestDescriptor).toEqual(takeLatest(GET_NAVIGATION, getNavigationSaga));
  });
});
