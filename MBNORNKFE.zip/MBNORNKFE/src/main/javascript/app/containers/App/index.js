/**
 *
 * App.js
 *
 * This component is the skeleton around the actual pages, and should only
 * contain code that should be seen on all pages. (e.g. navigation bar)
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { Switch, Route } from 'react-router-dom';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import { injectIntl, intlShape } from 'react-intl';
import injectSaga from 'utils/injectSaga';
import injectReducer from 'utils/injectReducer';

import HelloWorld from 'containers/HelloWorld';
import NotFoundPage from 'containers/NotFoundPage/Loadable';

import { Layouts } from 'tcmb-ui-components';
import Header from 'components/Header';
import Navigation from 'components/Navigation';
import Footer from 'components/Footer';
import img from 'resources/img/img';

import { makeSelectLocation, makeSelectNavigation } from './redux/selectors';
import reducer from './redux/reducer';
import saga from './redux/saga';

import messages from './messages';

class App extends React.Component {
  componentDidMount() {
    // To load navigation from a service uncomment this
    // import { getNavigation } from './redux/actions';
    // this.props.dispatch(getNavigation());
  }

  render() {
    return (
      <Layouts>
        <Header grid="header" siteName={this.props.intl.formatMessage(messages.siteName)} siteLogo={img.logo} />

        <div grid="2" gridwidth={3}>
          {this.props.navigation && <Navigation data={this.props.navigation} />}
        </div>

        <Switch grid="2" gridwidth={13}>
          <Route exact path="/" component={HelloWorld} />
          <Route component={NotFoundPage} />
        </Switch>

        <Footer
          grid="footer"
          data={this.props.navigation}
          siteLogo={img.logo}
          copyright={this.props.intl.formatMessage(messages.copyright)}
        />
      </Layouts>
    );
  }
}

App.propTypes = {
  intl: intlShape.isRequired,
  // eslint-disable-next-line react/no-unused-prop-types
  dispatch: PropTypes.func.isRequired,
  navigation: PropTypes.object,
};

const mapDispatchToProps = dispatch => ({
  dispatch,
});

const mapStateToProps = createStructuredSelector({
  navigation: makeSelectNavigation(),
  router: makeSelectLocation(),
});

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

const withReducer = injectReducer({ key: 'navigation', reducer });
const withSaga = injectSaga({ key: 'navigation', saga });

export default compose(
  withReducer,
  withSaga,
  withConnect,
)(injectIntl(App));
