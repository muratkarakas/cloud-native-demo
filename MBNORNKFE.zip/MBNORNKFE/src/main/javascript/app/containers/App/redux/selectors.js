import { createSelector } from 'reselect';
import { initialState } from './reducer';

const selectRouter = state => state.get('router');
const selectNavigationDomain = state => state.get('navigation', initialState);

const makeSelectLocation = () =>
  createSelector(
    selectRouter,
    routerState => routerState.get('location').toJS(),
  );

const makeSelectNavigation = () =>
  createSelector(
    selectNavigationDomain,
    substate => substate.toJS(),
  );

export { makeSelectLocation, makeSelectNavigation };
