/*
 * LocaleToggle Messages
 *
 * This contains all the text for the LanguageToggle component.
 */
import { defineMessages } from 'react-intl';

export const scope = 'tcmb.containers.LocaleToggle';

export default defineMessages({
  tr: {
    id: `${scope}.tr`,
    defaultMessage: 'tr',
  },
  en: {
    id: `${scope}.en`,
    defaultMessage: 'en',
  },
});
