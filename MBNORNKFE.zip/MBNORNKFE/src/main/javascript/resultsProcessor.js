/* eslint-disable */


module.exports = function() {  
    require('./node_modules/jest-bamboo-reporter').apply(this, arguments);
    return require('./node_modules/jest-sonar-reporter').apply(this, arguments);
    // add any other processor you need
};
