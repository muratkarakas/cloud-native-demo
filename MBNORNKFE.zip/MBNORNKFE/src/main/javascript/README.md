# Documentation

## Table of Contents

- [Development](development)


## Development

- Clone from git. Username ad.soyad and password.

```Shell

git clone http://tcmbgit.eteration.com/template-project-ui.git
git clone http://tcmbgit.eteration.com/tcmb-ui-components.git

```

- Change .npmrc file to set you npm repository.

```Shell
    # Uncomment to use Eteration public nexus repo 
    registry=http://nexus.eteration.com/repository/npm-all/
    strict-ssl=true

    # Uncomment to use TCMB internal nexus repo 
    #registry=https://atlas-test.tcmb.gov.tr/nexus/repository/npm-all/
    #strict-ssl=false
```

- Build and run.
-- Make sure you can can mount git folder as a docker volume check docker preferences.

```Shell
Windows PowerShell
docker run --rm -itv ${pwd}:/usr/src/app -w /usr/src/app node:latest npm i
docker run --rm -itv ${pwd}:/usr/src/app -w /usr/src/app -p 3000:3000 node:latest npm run start

```

```Shell
Unix
docker run --rm -itv  $(pwd):/usr/src/app -w /usr/src/app node:latest npm i
docker run --rm -itv  $(pwd):/usr/src/app -w /usr/src/app -p 3000:3000 node:latest npm run start

```
